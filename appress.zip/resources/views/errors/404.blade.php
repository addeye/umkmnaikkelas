@extends('layouts.error')

@section('title')
  404
@endsection

@section('content')
  <img class="error-mark animation-slide-top" src="{{url('remark/assets/images/404.png')}}" alt="...">
@endsection