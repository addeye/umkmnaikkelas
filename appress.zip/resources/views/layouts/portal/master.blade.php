<!DOCTYPE html>
<html class="no-js before-run" lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <meta name="description" content="bootstrap admin template">
    <meta name="author" content="">

    <title>@yield('title') | {{config('app.name')}}</title>
    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <link rel="apple-touch-icon" href="{{url('remark/assets/images/apple-touch-icon.png')}}">
    <link rel="shortcut icon" href="{{asset('images/logo-small.png')}}">

    <!-- Stylesheets -->
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
    {{Html::style('remark/assets/css/bootstrap.min.css')}}
    {{Html::style('kartika-upload/css/fileinput.min.css')}}
    {{Html::style('remark/assets/css/bootstrap-extend.min.css')}}
    {{Html::style('remark/assets/css/site.css')}}
    {{Html::style('css/custom.css')}}

    {{Html::style('remark/assets/vendor/animsition/animsition.css')}}
    {{Html::style('remark/assets/vendor/asscrollable/asScrollable.css')}}
    {{Html::style('remark/assets/vendor/switchery/switchery.css')}}
    {{Html::style('remark/assets/vendor/intro-js/introjs.css')}}
    {{Html::style('remark/assets/vendor/slidepanel/slidePanel.css')}}
    {{Html::style('remark/assets/vendor/flag-icon-css/flag-icon.css')}}

    <!-- Plugin -->
    {{Html::style('remark/assets/vendor/bootstrap-sweetalert/sweet-alert.css')}}
    {{Html::style('remark/assets/vendor/toastr/toastr.css')}}
    {{Html::style('remark/assets/vendor/asscrollable/asScrollable.css')}}
    {{Html::style('remark/assets/vendor/select2/select2.css')}}

            <!-- Fonts -->
    {{Html::style('remark/assets/fonts/font-awesome/font-awesome.css')}}
    {{Html::style('remark/assets/fonts/web-icons/web-icons.min.css')}}
    {{Html::style('remark/assets/fonts/brand-icons/brand-icons.min.css')}}
    <link rel='stylesheet' href='http://fonts.googleapis.com/css?family=Roboto:300,400,500,300italic'>

    {{Html::style('remark/assets/vendor/owl-carousel/owl.carousel.css')}}
    {{Html::style('remark/assets/vendor/slick-carousel/slick.css')}}
    @yield('css')

    <!--[if lt IE 9]>
    {{Html::script(asset('remark/assets/vendor/html5shiv/html5shiv.min.js'))}}
    <![endif]-->

    <!--[if lt IE 10]>
    {{Html::script(asset('remark/assets/vendor/media-match/media.match.min.js'))}}
    {{Html::script(asset('remark/assets/vendor/respond/respond.min.js'))}}
    <![endif]-->

    <!-- Scripts -->
    {{Html::script(asset('remark/assets/vendor/modernizr/modernizr.js'))}}
    {{Html::script(asset('remark/assets/vendor/breakpoints/breakpoints.js'))}}
    <script>
        Breakpoints();
    </script>
    <!-- Scripts -->
    <script>
        window.Laravel = {!! json_encode(['csrfToken' => csrf_token(),]) !!};
    </script>
</head>
<body>
<!--[if lt IE 8]>
<p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
<![endif]-->

@include('layouts.portal.header')

<!-- Page -->
@yield('content')
<!-- End Page -->
@yield('modal')

@include('layouts.portal.footer')

<!-- Core  -->
{{Html::script(asset('remark/assets/vendor/jquery/jquery.js'))}}
{{Html::script(asset('remark/assets/vendor/bootstrap/bootstrap.js'))}}
{{Html::script(asset('remark/assets/vendor/animsition/jquery.animsition.js'))}}
{{Html::script(asset('remark/assets/vendor/asscroll/jquery-asScroll.js'))}}
{{Html::script(asset('remark/assets/vendor/mousewheel/jquery.mousewheel.js'))}}
{{Html::script(asset('remark/assets/vendor/asscrollable/jquery.asScrollable.all.js'))}}
{{Html::script(asset('remark/assets/vendor/ashoverscroll/jquery-asHoverScroll.js'))}}

        <!-- Plugins -->
{{Html::script(asset('remark/assets/vendor/switchery/switchery.min.js'))}}
{{Html::script(asset('remark/assets/vendor/intro-js/intro.js'))}}
{{Html::script(asset('remark/assets/vendor/screenfull/screenfull.js'))}}
{{Html::script(asset('remark/assets/vendor/slidepanel/jquery-slidePanel.js'))}}

{{Html::script(asset('remark/assets/vendor/bootbox/bootbox.js'))}}
{{Html::script(asset('remark/assets/vendor/bootstrap-sweetalert/sweet-alert.js'))}}
{{Html::script(asset('remark/assets/vendor/toastr/toastr.js'))}}

{{Html::script(asset('remark/assets/vendor/select2/select2.min.js'))}}

{{Html::script(asset('kartika-upload/js/plugins/canvas-to-blob.min.js'))}}
{{Html::script(asset('kartika-upload/js/plugins/sortable.min.js'))}}
{{Html::script(asset('kartika-upload/js/plugins/purify.min.js'))}}
{{Html::script(asset('kartika-upload/js/fileinput.min.js'))}}

{{Html::script(asset('kartika-upload/themes/fa/theme.js'))}}
{{Html::script(asset('kartika-upload/js/locales/id.js'))}}

{{Html::script(asset('remark/assets/vendor/formatter-js/jquery.formatter.js'))}}

        <!-- Scripts -->
{{Html::script(asset('remark/assets/js/core.js'))}}
{{Html::script(asset('remark/assets/js/site.js'))}}

{{Html::script(asset('remark/assets/js/sections/menu.js'))}}
{{Html::script(asset('remark/assets/js/sections/menubar.js'))}}
{{Html::script(asset('remark/assets/js/sections/sidebar.js'))}}

{{Html::script(asset('remark/assets/js/configs/config-colors.js'))}}
{{Html::script(asset('remark/assets/js/configs/config-tour.js'))}}

{{Html::script(asset('remark/assets/js/components/asscrollable.js'))}}
{{Html::script(asset('remark/assets/js/components/animsition.js'))}}
{{Html::script(asset('remark/assets/js/components/slidepanel.js'))}}
{{Html::script(asset('remark/assets/js/components/switchery.js'))}}
{{Html::script(asset('remark/assets/js/components/asscrollable.js'))}}

{{Html::script(asset('remark/assets/vendor/slick-carousel/slick.js'))}}

{{Html::script(asset('remark/assets/js/components/bootbox.js'))}}
{{Html::script(asset('remark/assets/js/components/bootstrap-sweetalert.js'))}}
{{Html::script(asset('remark/assets/js/components/toastr.js'))}}
{{Html::script(asset('remark/assets/js/components/select2.js'))}}
{{Html::script(asset('remark/assets/js/components/formatter-js.js'))}}

<!-- Include this after the sweet alert js file -->
    <script type="text/javascript">
        $(window).load(function(){
  $(document).ready(function () {
      
      @if (Session::has('sweet_alert.alert'))
    
        swal({!! Session::get('sweet_alert.alert') !!});
    
@endif
    });
});
    </script>

<script>
    (function(document, window, $) {
        'use strict';

        var Site = window.Site;
        $(document).ready(function() {
            Site.run();
            $('#exampleSingleItem').slick();
            // Example Slick Autoplay
        // ----------------------
        $('#exampleAutoplay').slick({
          dots: false,
          infinite: true,
          speed: 500,
          slidesToShow: 1,
          slidesToScroll: 1,
          autoplay: true,
          autoplaySpeed: 2000,
          prevArrow: null,
         nextArrow: null,
        });

        });
    })(document, window, jQuery);
</script>

@yield('js')

</body>

</html>