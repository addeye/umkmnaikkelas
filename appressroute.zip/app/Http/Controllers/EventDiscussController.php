<?php

namespace App\Http\Controllers;

use App\EventDiscuss;
use Illuminate\Http\Request;

class EventDiscussController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\EventDiscuss  $eventDiscuss
     * @return \Illuminate\Http\Response
     */
    public function show(EventDiscuss $eventDiscuss)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\EventDiscuss  $eventDiscuss
     * @return \Illuminate\Http\Response
     */
    public function edit(EventDiscuss $eventDiscuss)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\EventDiscuss  $eventDiscuss
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, EventDiscuss $eventDiscuss)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\EventDiscuss  $eventDiscuss
     * @return \Illuminate\Http\Response
     */
    public function destroy(EventDiscuss $eventDiscuss)
    {
        //
    }
}
