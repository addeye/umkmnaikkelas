<?php

namespace App\Http\Controllers\Umkm;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class EventController extends Controller
{
    //
}
