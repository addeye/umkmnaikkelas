<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class OrderChatController extends Controller
{
    //
}
