<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;

class KonsultasiController extends Controller {
	public function getAll() {

	}
}
