<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class JasaPendampingan extends Model
{
    protected $table = 'jasa_pendampingan';
}
