<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BidangPendampingan extends Model {
	protected $table = 'bidang_pendampingan';

	public $timestamps = false;
}
