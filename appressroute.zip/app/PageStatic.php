<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PageStatic extends Model {
	protected $table = 'pages_static';
}
