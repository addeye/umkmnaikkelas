@extends('layouts.error')

@section('title')
  503
@endsection

@section('content')
  <img class="error-mark animation-slide-top" src="{{url('remark/assets/images/503.png')}}" alt="...">
@endsection