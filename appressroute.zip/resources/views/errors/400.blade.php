@extends('layouts.error')

@section('title')
  400
@endsection

@section('content')
  <img class="error-mark animation-slide-top" src="{{url('remark/assets/images/400.png')}}" alt="...">
@endsection