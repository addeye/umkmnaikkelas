@extends('layouts.error')

@section('title')
  403
@endsection

@section('content')
  <img class="error-mark animation-slide-top" src="{{url('remark/assets/images/403.png')}}" alt="...">
@endsection