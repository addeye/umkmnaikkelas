@extends('layouts.error')

@section('title')
  500
@endsection

@section('content')
  <img class="error-mark animation-slide-top" src="{{url('remark/assets/images/500.png')}}" alt="...">
@endsection