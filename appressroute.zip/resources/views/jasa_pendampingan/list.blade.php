@extends('layouts.portal.master')

@section('content')
    <div class="container-fluid page-profile">
        <div class="page-content animsition">
            <div class="row">
                <div class="col-md-12">
                    <div class="panel">
                        <div class="panel-heading">
                            <div class="panel-title">
                                Jasa Pendampingan
                            </div>
                        </div>
                        <div class="panel-body">
                            <table class="table table-bordered">
                                <tr></tr>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection