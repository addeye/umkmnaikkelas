<?php
/**
 * Created by PhpStorm.
 * User: deye
 * Date: 5/13/17
 * Time: 1:22 PM
 */
?>
<div class="row">
    <div class="col-md-12">
        <h3><span class="icon fa-exclamation"></span> Maaf Anda Harus Terdaftar Sebagai Pendamping / UMKM Terlebih Dahulu</h3>
    </div>
</div>
