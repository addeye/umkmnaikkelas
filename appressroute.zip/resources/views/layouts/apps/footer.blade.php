<!-- Footer -->
  <footer class="site-footer">
    <span class="site-footer-legal">&copy; 2017 Peac Bromo</span>
    <div class="site-footer-right">
      Crafted with <i class="red-600 wb wb-heart"></i> by <a href="javascript:void()">Deye</a>
    </div>
  </footer>