<!-- Footer -->
  <div id="footer">
  	<footer style="margin-left: 0px !important;" class="footer site-footer text-center">
    <span class="site-footer-legal">&copy; 2017 Peac Bromo</span>
  </footer>
  </div>